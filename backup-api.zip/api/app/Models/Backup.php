<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Backup extends Model
{

    /**
     * The name of the "created at" column.
     *
     * @var string
     */
    const CREATED_AT = 'created_at';

    /**
     * The name of the "updated at" column.
     *
     * @var string
     */
    const UPDATED_AT = 'updated_at';

	protected $table = 'backup';

	protected $fillable = [

		'id',
		'created_at',
		'updated_at',
		'url',
		'type',
		'title',
		'content',
		'is_done',
                'has_rel',
                'has_error'

	];

}