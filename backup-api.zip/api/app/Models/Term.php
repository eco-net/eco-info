<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Term extends Model
{

	public $timestamps = false;

	protected $table = 'terms';

	protected $fillable = [

		'name',
		'slug'

	];

	public function taxonomy()
    {
        return $this->hasMany('App\Models\TermTaxonomy', 'term_id', 'term_taxonomy_id');
    }

}