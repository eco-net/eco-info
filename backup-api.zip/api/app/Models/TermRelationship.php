<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TermRelationship extends Model
{

	public $timestamps = false;

	protected $table = 'term_relationships';

	protected $fillable = [

		'term_taxonomy_id',
		'object_id',

	];

}