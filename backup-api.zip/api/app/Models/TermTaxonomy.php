<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TermTaxonomy extends Model
{

	public $timestamps = false;

	protected $table = 'term_taxonomy';

	protected $fillable = [

		'term_id',
		'taxonomy',
		'parent',
		'count'

	];

	public function term()
    {
        return $this->belongsTo('App\Models\Term','term_id', 'term_id');
    }

}