<?php

// Collect data
$data = array(
	'post_title' => $post_title,
	'post_name' => $post_name,
	'guid' => $guid,
	'post_author' => $post_author,
	'post_content' => $post_content,
	'post_excerpt' => $post_excerpt,
	'post_type' => $post_type,
	'categories' => $categories,
	'tags' => $tags,
	'level' => 2,
	'postmeta' => array(
		'_listing_created' => 1,
		'_order_date' => time(),
		'_listing_status' => 'active',
		'_content_field_7' => maybe_serialize(serialize(array('url' => $website, 'text' => 'Se vores hjemmeside'))),
		'_content_field_8' => $email,
		'_content_field_14' => $nr,
		'_content_field_15' => $lang,
		'_content_field_16' => $author,
		'_content_field_17' => $publisher,
		'_content_field_18' => $publish_year
	)
);
