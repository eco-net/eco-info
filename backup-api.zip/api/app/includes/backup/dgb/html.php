<?php

// Create DOM from URL or file
$html = str_get_html($url);

if(empty($html->find('td.contentHeader1', 1)->plaintext)){
	$this->Backup
	->where('id', $Backup->id)
	->update(['has_error' => 1]);
	return die('ERROR');
}

// Find title
$post_title =  trim(explode('<br>', strip_tags($html->find('td.contentHeader1', 1)->outertext, '<br>'))[0]);

$post_name = sanitize_title($post_title);

if(!empty($html->find('span.listheader', 0))){
$post_excerpt = trim(explode('<span>', strip_tags($html->find('span.listheader', 0)->outertext, '<span>'))[0]);
}


// Find content from html and look for rel link

$dgs_title = trim($html->find('a[title="Viser denne organisation"]',0)->plaintext);


$Post_dgs = $this->Post->where('post_title', 'like', '%' . $dgs_title .'%')->first();



if(empty($Post_dgs)){
	$this->Backup
	->where('id', $Backup->id)
	->update(['has_error' => 1]);
	return die('ERROR');
}


$post_content = trim($html->find('p', 2)->outertext);


// Find categories from html
foreach ($html->find('a[title="Finder publikationer i denne kategori"]') as $category) {
	$categories[] = trim($category->plaintext);
}

// Find tags from html
foreach ($html->find('a[title="Finder publikationer tilknyttet dette emne"]') as $tag) {
	$tags[] = trim($tag->plaintext);
}

// Find location info
$faqs = $html->find('span.faktaboksheader');

foreach($faqs as $info)
{
	$raw_data[] = $info->parent;
}

$info_data = $raw_data[0]->outertext;

$info_data = strip_tags($info_data, '<br>');

$info_data = preg_replace('/\s+/', '', $info_data);

$info_data = explode('<br>', $info_data);


foreach($info_data as $key => $value)
{

	if($value == 'ISBN/ISSNnummer')
	{
		$nr = keep_spaces($info_data[$key+1]);
	}
	
	if($value == 'Forfatter')
	{
		$author = keep_spaces($info_data[$key+1]);
	}
	
	if($value == 'Sprog')
	{
		$lang = $info_data[$key+1];
	}
	
	if($value == 'Udgiver')
	{
		$publisher = keep_spaces($info_data[$key+1]);
	}
	
	if($value == 'Udgivelses&aring;r')
	{
		$publish_year = $info_data[$key+1];
	}
	
	if($value == 'Udgiversmail')
	{
		$email = $info_data[$key+1];
	}
	
	if($value == 'UdgiversWWW')
	{
		$website = $info_data[$key+1];
	}
	
}
