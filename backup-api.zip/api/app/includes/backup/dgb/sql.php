<?php

if(DB_STATUS){

	// Get taxonomies
	
	
	if(!empty($data['tags']) || !empty($data['categories']))
	{

		// Categories
		$category_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'w2dc-category')->get();
	
		foreach ($category_taxonomies as $taxonomy) 
		{
	
			if (in_array($taxonomy['term']->name, $data['categories'])) {
				$category_ids[] = $taxonomy['term']->term_id;
			}
		}
	
		// Tags
	
		$tags_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'w2dc-tag')->get();
	
		foreach ($tags_taxonomies as $taxonomy) 
		{              
			if (in_array($taxonomy['term']->name, $data['tags'])) {
				$tag_ids[] = $taxonomy['term']->term_id;
			}
		}
	}


	// Merge taxonomies
	$taxonomies = '';
	if(!empty($data['tags']) && !empty($data['categories'])){
		$taxonomies = array_merge_recursive($category_ids, $tag_ids);
	} elseif(!empty($data['tags'])) {
		$taxonomies = $tag_ids;
	} elseif(!empty($data['categories'])) {
		$taxonomies = $category_ids;
	}
	
	if(empty($taxonomies)){
		$this->Backup
		->where('id', $Backup->id)
		->update(['has_error' => 1]);
		return die('ERROR');
	
	}
	
	// Create post
	$Post = $this->Post->create([
		'post_title' => $data['post_title'],
		'post_name' =>  $data['post_name'],
		'post_content' => $data['post_content'],
		'post_excerpt' => $data['post_excerpt'],
		'post_type' => $data['post_type'],
		'post_author' => $Post_dgs->post_author,
		'guid' => $data['guid']
	]);



	// Create post meta
	foreach ($data['postmeta'] as $key => $value) {
		$this->PostMeta->create([
			'post_id' => $Post->id,
			'meta_key' => $key,
			'meta_value' => $value,
		]);
	}

	if(!empty($taxonomies))
	{
		// Create taxonomies relationship
		foreach($taxonomies as $term)
		{
			$this->TermRelationship->create([
				'term_taxonomy_id' => $term,
				'object_id' => $Post->id,
			]);
		}
	
		foreach ($category_ids as $taxonomy) 
		{
			$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
		}
	
		foreach ($tag_ids as $taxonomy) 
		{
			$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
		}
	}
	

	// Create level relationship
	$this->W2dcLevelRelationship->create([
		'post_id' => $Post->id,
		'level_id' => $data['level']
	]);


	// Update status
	$this->Backup
	->where('id', $Backup->id)
	->update([
		'post_id' => $Post->id,
		'is_done' => 1,
		'has_error' => 0
	]);
	
}