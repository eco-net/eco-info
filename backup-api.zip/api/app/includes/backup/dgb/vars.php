<?php


// Default vars
$post_title = '';
$post_name = '';
$guid = 'http://xn--grntoverblik-wjb.dk/search/detail/dgs/';
$post_type = 'w2dc_listing';
$post_author = 2;
$post_content = '';
$post_excerpt = '';
$categories = '';
$tags = '';
$email = '';
$website = '';
$nr = '';
$author = '';
$lang = '';
$publisher = '';
$publish_year = '';
