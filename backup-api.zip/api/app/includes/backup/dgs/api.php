<?php

$city = getDkCommune($zipcode);

if(empty($city))
{

	if(DEBUG)
	{
		$this->Backup->where('id', $Backup->id)->update(['has_error' => 1]);
		error_log("API ERROR: Timeout or failed to locate city on '$post_title'!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
                $no_location = true;
	}

}

if(!$no_location)
{


$region = getDkRegion($zipcode);
$coordinates = getCoordinates($address . ' ' . $zipcode . ' ' . $city . ' ' . $region);

}




if(empty($coordinates))
{

	if(DEBUG)
	{
		error_log("API ERROR: Timeout or failed to get coordinates on '$post_title'!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
	}	

}