<?php

// Create DOM from URL or file
$html = str_get_html($url);

if(!$html){
	$this->Backup->where('id', $Backup->id)->update(['has_error' => 1]);
	error_log("API ERROR: Timeout or failed to get html from ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
	die('API ERROR! See log for details.');
}

//
$post_title = trim($html->find('td.contentHeader1', 0)->plaintext);

$post_name = sanitize_title($post_title);

if($html->find('div.contentHeader1', 0)->plaintext)
{
$post_title .= ' (ophørt)';
}


// Find content from html and look for rel link

if(!empty($html->find('a[title="Viser denne publikation"]'))){

	$post_content = _utf8_decode($html->find('p',0)->outertext);
	
	$this->Backup
	->where('id', $Backup->id)
	->update(['has_rel' => 1]);
	
} else {

	$post_content = $html->find('p',0)->outertext;

	$this->Backup
	->where('id', $Backup->id)
	->update(['is_done' => 1]);
}


// Find categories from html
foreach ($html->find('a[title="Finder organisationer i denne kategori"]') as $category) {
	$categories[] = _utf8_decode(trim($category->plaintext));
}

// Find tags from html
foreach ($html->find('a[title="Finder organisationer tilknyttet dette emne"]') as $tag) {
	$tags[] = _utf8_decode(trim($tag->plaintext));
}

// Find location info
$location = $html->find('span.faktaboksheader');

foreach($location as $info)
{
	$raw_location_data[] = $info->parent;
}

$location_data = $raw_location_data[0]->outertext;

$location_data = strip_tags($location_data, '<br>');

$location_data = preg_replace('/\s+/', '', $location_data);

$location_info = explode('<br>', $location_data);


// Find zipcode and Address
foreach($location_info as $key => $value)
{

   if(preg_match('/^(\d{4})/', $value))
   {
   $zipcode = extract_zipcode($value);

   $address = $location_info[$key-1];
   $address = ltrim(preg_replace('/(?<!\ )[A-Z]/', ' $0', $address));
   $address = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $address);

   if(!empty($location_info[$key-2]))
   {
    $extra = ltrim(preg_replace('/(?<!\ )[A-Z]/', ' $0', $location_info[$key-2]));
    $extra =  preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $extra);

   }
   break;
   }
}


// Fix spaces
if(strpos($location_info, 'og') !== false)
{
	$location_info = str_replace('og',' og ',$location_info);
} 
elseif(strpos($location_info, '&') !== false)
{
	$location_info = str_replace('&',' & ',$location_info);
}

// Find extra info
foreach($location_info as $key => $value)
{	

	if($value == 'Telefon')
	{
		$phone = $location_info[$key+1];
	}

	if($value == 'Fax')
	{
		$fax = $location_info[$key+1];
	}
	
	if($value == 'E-mail')
	{
		$email= sanitize_email($location_info[$key+1]);
	}
	
	if($value == 'Hjemmeside')
	{
		$website = $location_info[$key+1];
	}
	
	if($value == 'Kontaktperson')
	{
		if($location_info[$key+2] != '')
		{
			$contactperson = $location_info[$key+1] . ' ' . $location_info[$key+2];
			$contactperson = preg_replace('/(?<!\ )[A-Z]/', ' $0', $contactperson);
			$contactperson = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $contactperson);
		} 
		
		else
		{
			$contactperson = $location_info[$key+1];
			$contactperson = preg_replace('/(?<!\ )[A-Z]/', ' $0', $contactperson);
			$contactperson = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $contactperson);
			
		}
		
	}
}