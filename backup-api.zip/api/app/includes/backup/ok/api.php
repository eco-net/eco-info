<?php

$city = getDkCommune($zipcode);

if(empty($city))
{

	if(DEBUG)
	{
		$this->Backup->where('id',$Backup->id)->update(['has_error' => 1]);
		return die('ERROR');

	}

}

$region = getDkRegion($zipcode);

if(empty($region))
{

	if(DEBUG)
	{
		$this->Backup->where('id',$Backup->id)->update(['has_error' => 1]);
		return die('ERROR');
	}

}

$coordinates = getCoordinates($address . ' ' . $zipcode . ' ' . $city . ' ' . $region);


if(empty($coordinates))
{

	if(DEBUG)
	{
		$this->Backup->where('id',$Backup->id)->update(['has_error' => 1]);
		return die('ERROR');
	}	

}