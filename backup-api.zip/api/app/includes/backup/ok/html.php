<?php

// Create DOM from URL or file
$html = str_get_html($url);

if(empty($html->find('td.contentHeader1', 1)->plaintext)){
	$this->Backup
	->where('id', $Backup->id)
	->update(['has_error' => 1]);
	return die('ERROR');
}

//
$post_title =  trim(explode('<br>', strip_tags($html->find('td.contentHeader1', 1)->outertext, '<br>'))[0]);

$post_name = sanitize_title($post_title);


if(!empty($html->find('span.listheaderItalic', 0))){
$post_excerpt = trim($html->find('span.listheaderItalic', 0)->plaintext);
}


// Find content from html and look for rel link

$dgs_title = trim($html->find('a[title="Viser denne organisation"]',0)->plaintext);


$Post_dgs = $this->Post->where('post_title', 'like', '%' . $dgs_title .'%')->first();



if(empty($Post_dgs)){
	$this->Backup
	->where('id', $Backup->id)
	->update(['has_error' => 1]);
	return die('ERROR');
}


// Find categories from html
foreach ($html->find('a[title="Finder publikationer i denne kategori"]') as $category) {
	$categories[] = trim($category->plaintext);
}

// Find tags from html
foreach ($html->find('a[title="Finder arrangementer tilknyttet dette emne"]') as $tag) {
	$tags[] = trim($tag->plaintext);
}

// Find location info
$location = $html->find('span.faktaboksheader');


foreach($location as $info)
{
	$raw_location_data[] = $info->parent;
}

$location_data = $raw_location_data[0]->outertext;

$location_data = strip_tags($location_data, '<br>');

//$location_data = preg_replace('/\s+/', '', $location_data);

$location_info = explode('<br>', $location_data);


// Find zipcode and Address
foreach($location_info as $key => $value)
{

   if($value == 'Sted')
   {
   $zipcode = extract_zipcode($value);

   $address = $location_info[$key-1];
   $address = ltrim(preg_replace('/(?<!\ )[A-Z]/', ' $0', $address));
   $address = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $address);

   if(!empty($location_info[$key-2]))
   {
    $extra = ltrim(preg_replace('/(?<!\ )[A-Z]/', ' $0', $location_info[$key-2]));
    $extra =  preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $extra);

   }
   break;
   }
}


// Fix spaces


// Find extra info
foreach($location_info as $key => $value)
{	

	if($value == '  Dato')
	{
	
	$start_date = dk_strtotime(trim(explode('-', $location_info[$key+1])[0]));
	$end_date = dk_strtotime(trim(explode('-', $location_info[$key+1])[1]));
	
	$start_time_hour = explode('.',trim(str_replace('Start:','',$location_info[$key+3])))[0];
	$start_time_minute = explode('.',trim(str_replace('Start:','',$location_info[$key+3])))[1];
	
	$end_time_hour = explode('.',trim(str_replace('Slut:','',$location_info[$key+4])))[0];
	$end_time_minute = explode('.',trim(str_replace('Slut:','',$location_info[$key+4])))[1];
	
	}

	if($value == 'Telefon')
	{
		$phone = $location_info[$key+1];
	}

	
	if($value == 'E-mail')
	{
		$email= sanitize_email($location_info[$key+1]);
	}
	
	if($value == 'WWW')
	{
		$website = $location_info[$key+1];
	}
	
	if($value == 'Arrang&oslash;r(er)')
	{
		if($location_info[$key+2] != '')
		{
			$organizer = $location_info[$key+1] . ' ' . $location_info[$key+2];
			$organizer = preg_replace('/(?<!\ )[A-Z]/', ' $0', $organizer);
			$organizer = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $organizer);
		} 
		
		else
		{
			$organizer = $location_info[$key+1];
			$organizer = preg_replace('/(?<!\ )[A-Z]/', ' $0', $organizer);
			$organizer = preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', $organizer);
			
		}
		
	}
}