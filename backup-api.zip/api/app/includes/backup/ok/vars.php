<?php


// Default vars
$post_title = '';
$post_excerpt = '';
$post_name = '';
$guid = 'http://xn--grntoverblik-wjb.dk/search/detail/ok/';
$post_type = 'w2dc_listing';
$post_author = 2;
$post_content = '';
$categories = '';
$tags = '';
$address = '';
$extra = '';
$zipcode = '';
$city = '';
$region = '';
$phone = '';
$email = '';
$website = '';
$organizer= '';
$start_date = '';
$end_date = '';
$start_time_hour = '';
$start_time_minute = '';
$end_time_hour = '';
$end_time_minute = '';