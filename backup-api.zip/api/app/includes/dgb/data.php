<?php

// Collect data
$data = array(
	'post_title' => $post_title,
	'post_name' => $post_name,
	'guid' => $guid,
	'post_author' => $post_author,
	'post_content' => $post_content,
	'post_type' => $post_type,
	'categories' => $categories,
	'tags' => $tags,
);