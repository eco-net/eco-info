<?php

if(DB_STATUS){

	// Create new post
	$post = $this->Post->create([

		'post_title' => $data['post_title'],
		'post_name' =>  $data['post_name'],
		'post_content' => $data['post_content'],
		'post_type' => $data['post_type'],
		'post_author' => $data['post_author'],
		'guid' => $data['guid']

	]);

	// Update guid
	$this->Post->where('ID','=', $post->id)->update([
		'guid'=> $data['guid'] . '&#038;p=' . $post->id
	]);

	// Get taxonomies

	// Categories
	$category_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'knowledgebase_category')->get();

	foreach ($category_taxonomies as $taxonomy) 
	{

		if (in_array($taxonomy['term']->name, $data['categories'])) {
			$category_ids[] = $taxonomy['term']->term_id;
		}
	}

	foreach ($category_ids as $taxonomy) 
	{
		$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
	}


	// Tags

	$tags_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'knowledgebase_tags')->get();

	foreach ($tags_taxonomies as $taxonomy) 
	{

		if (in_array($taxonomy['term']->name, $data['tags'])) {
			$tag_ids[] = $taxonomy['term']->term_id;
		}
	}

	foreach ($tag_ids as $taxonomy) 
	{
		$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
	}


	// Merge taxonomies
	$taxonomies = array_merge_recursive($category_ids, $tag_ids);


	// Create taxonomies relationship
	foreach($taxonomies as $term)
	{
		$this->TermRelationship->create([
			'term_taxonomy_id' => $term,
			'object_id' => $post->id,
		]);
	}


	// Update status
	$this->Link
	->where('link_id', $link->link_id)
	->update([
		'link_post_id' => $post->id
	]);



}