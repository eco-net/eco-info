<?php

// clean up memory
$html->clear();
unset($html);