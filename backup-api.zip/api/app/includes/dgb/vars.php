<?php

// Default vars
$post_title = '';
$post_name = '';
$guid = 'http://xn--grntoverblik-wjb.dk/?post_type=knowledgebase';
$post_type = 'knowledgebase';
$post_author = 2;
$post_content = '';
$categories = '';
$category_ids = '';
$tags = '';
