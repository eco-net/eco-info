<?php

$city = getDkCommune($zipcode);

if(empty($city))
{

	if(DEBUG)
	{
		$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
		error_log("API ERROR: Timeout or failed to locate city on '$post_title' ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		die('API ERROR! See log for details.');
	}

}

$region = getDkRegion($zipcode);

if(empty($region))
{

	if(DEBUG)
	{
		$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
		error_log("API ERROR: Timeout or failed to locate region on '$post_title' ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		die('API ERROR! See log for details.');
	}

}

$coordinates = getCoordinates($address . ' ' . $zipcode . ' ' . $city . ' ' . $region);


if(empty($coordinates))
{

	if(DEBUG)
	{
		$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
		error_log("API ERROR: Timeout or failed to get coordinates on '$post_title' ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		die('API ERROR! See log for details.');
	}	

}