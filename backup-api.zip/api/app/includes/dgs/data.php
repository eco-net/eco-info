<?php

// Collect data
$data = array(
	'post_title' => $post_title,
	'post_name' => $post_name,
	'guid' => $guid,
	'post_author' => $post_author,
	'post_content' => $post_content,
	'post_type' => $post_type,
	'categories' => $categories,
	'tags' => $tags,
	'address' => $address, 
	'extra' => $extra,
	'zipcode' => $zipcode,
	'city' => $city,
	'region' => $region,
	'phone' => $phone,
	'fax' => $fax,
	'email' => $email,
	'website' => $website,
	'website_text' => 'Se vores hjemmeside',
	'contactperson' => $contactperson,
	'map_coords_1' => $coordinates[0],
	'map_coords_2' => $coordinates[1],
	'level' => 1,
	'postmeta' => array(
		'_map_zoom' => 11,
		'_listing_created' => 1,
		'_order_date' => time(),
		'_listing_status' => 'active'
	)
);
