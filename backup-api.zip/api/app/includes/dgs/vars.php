<?php


// Default vars
$post_title = '';
$post_name = '';
$guid = 'http://xn--grntoverblik-wjb.dk/dgs/side/';
$post_type = 'w2dc_listing';
$post_author = 2;
$post_content = '';
$categories = '';
$tags = '';
$address = '';
$extra = '';
$zipcode = '';
$city = '';
$region = '';
$phone = '';
$fax = '';
$email = '';
$website = '';
$contactperson = '';