<?php

if(DB_STATUS){

	$post = $this->Post
	->where('ID', '=', $link->link_post_id)
	->update([
		'post_content' => $post_content
	]);

	if(!$post)
	{
		$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
		error_log("API ERROR: Failed to insert link for ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		die('API ERROR! See log for details.');
	} else {
		$this->Link->where('link_id',$link->link_id)->update(['link_done' => 1]);
	}

}