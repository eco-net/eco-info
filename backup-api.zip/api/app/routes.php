<?php

// Test
$app->get('/test', function($request, $response){

    do_shortcode('[category-count cat_id="160"]');

});


// Test
$app->get('/email/fix', function($request, $response){
  
  ?>
<meta http-equiv="refresh" content="2">
<?php
  
  $Email = $this->Email;

  $body = $Email->get(1)['body'];
  
if (strpos($body, 'Diagnostic-Code') !== false) {
  
  	// Remove user from newsletter list
     $email = extract_emails($body)[0];    
     $this->Newsletter->where('email',$email)->delete();
  
     // Make user inactive
 	 $user = $this->User->where('user_email', $email)->first(['ID']);
     $this->UserMeta
       ->where('user_id', $user->ID)
       ->where('meta_key', 'account_status')
       ->update(['meta_value' => 'inactive']);
  
  // Move user posts to archive
     $posts = $this->Post
      ->where('post_author', $user->ID)
      ->where('post_type', 'w2dc_listing')->get();

    foreach($posts as $post) {
       $this->W2dcLevelRelationship
         ->where('post_id', $post->ID)
         ->update(['level_id' => 4]);
    }
	
}
  $Email->move(1, 'Trash');
  $Email->close();
  
});


$app->get('/test/crawler', function($request,$response){
    return $this->view->render($response, 'crawler.twig', ['crawler' => new \App\Models\Crawler]);
});

// View backup
$app->get('/backup[/{s}/{skip}/{take}]', function($request, $response, $args){

	if(empty($args)) {
	$args['take'] = 1;
	$args['skip'] = 0;

        $Data = $this->Backup->skip($args['skip'])->take($args['take'])->first();

	} else {

        $s = $args['s'];

        $Data = $this->Backup->where('title', 'like', "%$s%")->skip($args['skip'])->take($args['take'])->get();

        }
   

if(!empty($Data)) {   

    return $this->view->render($response, 'backup.twig', [
        'data' => $Data,
        'args' => $args
    ]);

}
   

})->setName('backup');


// API's
$app->get('/crawl/dgs', function($request, $response){

        $next_file = 'resources/storage/dgs/next.php';
	$cat_file = 'resources/storage/dgs/catlist.php';
	$catlist = unserialize(file_get_contents($cat_file));

	$Crawler = $this->Crawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGS-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	    }

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


$app->get('/crawl/dgb', function($request, $response){

	$next_file = 'resources/storage/dgb/next.php';
	$cat_file = 'resources/storage/dgb/catlist.php';

	$Crawler = $this->Crawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGB-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	    }

	    $catlist = unserialize(file_get_contents($cat_file));

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


// Create dgs pages
$app->get('/create/dgs', function($request, $response, $args) {

	$link = $this->Link
	->where('link_type', 'dgs')
	->where('link_post_id', 0)
	->where('link_done',0)
	->where('link_error',0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/dgs/vars.php';

		require 'includes/dgs/html.php';

		require 'includes/dgs/api.php';

		require 'includes/dgs/data.php';

		require 'includes/dgs/sql.php';

		require 'includes/dgs/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " DGS-creation done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});


// Create dgb pages
$app->get('/create/dgb', function($request, $response, $args) {

	$link = $this->Link
	->where('link_type', 'dgb')
	->where('link_post_id', 0)
	->where('link_done',0)
	->where('link_error',0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/dgb/vars.php';

		require 'includes/dgb/html.php';

		require 'includes/dgb/data.php';

		require 'includes/dgb/sql.php';

		require 'includes/dgb/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " DGB-creation done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});


// Error fix dgs
$app->get('/error/fix/dgs', function($request, $response, $args) {

	$link = $this->Link
	->where('link_type', 'dgs')
	->where('link_post_id', 0)
	->where('link_done',0)
	->where('link_error',1)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/dgs/vars.php';

		require 'includes/dgs/html.php';

		require 'includes/dgs/api.php';

		require 'includes/dgs/data.php';

		require 'includes/dgs/sql.php';

		require 'includes/dgs/terminate.php';

        $this->Link
	->where('link_id', $link->link_id)
	->update(['link_error' => 0]);

	} else {
		error_log(date('Y-m-d H:i:s') . " DGS-FIX-creation done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});



// Link dgs and dgs together
$app->get('/link', function($request, $response, $args) {

	$link = $this->Link
	->where('link_rel', 1)
	->where('link_done', 0)
	->where('link_error', 0)
	->where('link_post_id', '>', 0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/link/html.php';
		require 'includes/link/sql.php';
		require 'includes/link/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " Linking done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});


// Backup dgs
$app->get('/backup/dgs', function($request, $response){

        $next_file = 'resources/storage/dgs/next.php';
	$cat_file = 'resources/storage/dgs/catlist.php';
        $catlist = unserialize(file_get_contents($cat_file));

	$Crawler = $this->BackupCrawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGS-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
                return die('STOP');
	    }

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


// Backup dgb
$app->get('/backup/dgb', function($request, $response){
       
?>
<meta http-equiv="refresh" content="5">
<?php

	$next_file = 'resources/storage/dgb/next.php';
	$cat_file = 'resources/storage/dgb/catlist.php';
        $catlist = unserialize(file_get_contents($cat_file));

	$Crawler = $this->BackupCrawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGB-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
                return die('STOP');
	    }

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


$app->get('/create/missing/dgs', function($request, $response){


?>
<meta http-equiv="refresh" content="5">
<?php

$Backup = $this->Backup
	->where('type', 'dgs')
	->where('has_error',1)
	->first();
	
	
	if(empty($Backup)){
		error_log(date('Y-m-d H:i:s') . " DGS-backup done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		return die('STOP');
	}
	
	
$Post =	$this->Post
	->where('post_title', $Backup->title)
	->first();


	if(empty($Post)){

		$url = $Backup->content;

		require 'includes/backup/dgs/vars.php';

		require 'includes/backup/dgs/html.php';

		require 'includes/backup/dgs/api.php';

		require 'includes/backup/dgs/data.php';

		require 'includes/backup/dgs/sql.php';

		require 'includes/backup/dgs/terminate.php';
		
		return die('OK');

	} else {
	
	// Check for empty content
	if(empty($Post->post_content)){
	
	$html = str_get_html($Backup->content);
	
	$post_content = _utf8_decode($html->find('p',0)->outertext);
	
		$this->Post
		->where('ID', $Post->ID)
		->update([
		'post_content' => $post_content
	]);
	
	}
	
	// Update status
	$Backup
	->update([
		'post_id' => $Post->ID,
		'is_done' => 1,
		'has_error' => 0
	]);
	
	
        return die('STOP');
	}

});


//Restore dgb pages

$app->get('/create/missing/dgb', function($request, $response)
{

?>
<meta http-equiv="refresh" content="1">
<?php

$Backup = $this->Backup
	->where('type', 'dgb')
	->where('is_done',0)
        ->where('has_error',0)
	->first();
	
	
	if(empty($Backup)){
		return die('STOP');
	}
	
		$url = $Backup->content;

		require 'includes/backup/dgb/vars.php';

		require 'includes/backup/dgb/html.php';

		require 'includes/backup/dgb/data.php';

		require 'includes/backup/dgb/sql.php';

		require 'includes/backup/dgb/terminate.php';
			
       		return die('OK');

});


$app->get('/fix/missing/dgb', function($request, $response)
{

$Backup = $this->Backup
	->where('type', 'dgb')
	->where('is_done',0)
        ->where('has_error',1)
	->first();
	
	$html = str_get_html($Backup->content);
	
	$dgs_title = trim($html->find('a[title="Viser denne organisation"]',0)->plaintext);
	
	if(empty($dgs_title)){
	$Backup->update(['is_done' =>'1']);
	}

$Post_dgs = $this->Post->where('post_title', 'like', '%' . $dgs_title .'%')->first();
	var_dump($Backup->url, $dgs_title, $Post_dgs->post_title);
	die;

});


// Ok kalender crawl
$app->get('/crawl/ok', function($request, $response)
{

?>
<meta http-equiv="refresh" content="5">
<?php


	$next_file = 'resources/storage/ok/next.php';

	$Crawler = $this->BackupCrawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{
		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
		echo 'STOP';
	} 


	if($Crawler->done)
	{
	unlink($next_file);

	}

	echo 'OK';

});



// Ok calender create
$app->get('/backup/create/ok', function($request, $response)
{

$Backup = $this->Backup
	->where('type', 'ok')
	->where('is_done',0)
        ->where('has_error',0)
	->first();
	
	
	if(empty($Backup)){
		return die('STOP');
	}
	
		$url = $Backup->content;

		require 'includes/backup/ok/vars.php';

		require 'includes/backup/ok/html.php';

		require 'includes/backup/ok/data.php';

		require 'includes/backup/ok/sql.php';

		require 'includes/backup/ok/terminate.php';
			
       		return die('OK');

});