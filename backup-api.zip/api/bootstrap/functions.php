<?php

// Wordpress functions
require_once '../wp/wp-load.php';


// Custom functions

function getCoordinates($address, $timeout = 10)
{

trim($address);
$address = str_replace(" ", "+", $address); // replace all the white space with "+" sign to match with google search pattern

$url = "http://maps.google.com/maps/api/geocode/json?sensor=false&address=$address";

$opts = array('http' =>
    array(
        'method'  => 'GET',
        'timeout' => $timeout
    )
);

$context  = stream_context_create($opts);

$response = file_get_contents($url, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

$json = json_decode($response,TRUE); //generate array object from the response from the web

$data = $json['results'][0]['geometry']['location']['lat'].",".$json['results'][0]['geometry']['location']['lng'];

return explode(',', $data);

}

function getDkCommune($zip, $timeout = 10)
{

  trim($zip);
  $request = "https://api.websupport.dk/dk/zipcode/$zip";

  $opts = array('http' =>
      array(
          'method'  => 'GET',
          'timeout' => $timeout
      )
  );

  $context  = stream_context_create($opts);

  $response = file_get_contents($request, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

  $data = json_decode($response, true);

  return $data['commune_name'];

}


function getDkRegion($zip, $timeout = 10)
{

  trim($zip);
  $request = "https://api.websupport.dk/dk/zipcode/$zip";
  $opts = array('http' =>
      array(
          'method'  => 'GET',
          'timeout' => $timeout
      )
  );

  $context  = stream_context_create($opts);

  $response = file_get_contents($request, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

  $data = json_decode($response, true);

  return $data['region_name'];
}

function get_random_username($chars, $length = 12) {
  $validCharacters = $chars . '12345abcdefghijklmnopqrstuvwxyz678910';
  $validCharNumber = strlen($validCharacters);
  $result = '';
  for ($i = 0; $i < $length; $i++) {
    $index = mt_rand(0, $validCharNumber - 1);
    $result .= $validCharacters[$index];
  }
  return $result;
}

function extract_zipcode($address) {
    $zipcode = preg_match("/(\d{4})/", $address, $matches);
    return $remove_statecode ? preg_replace("/[^\d\-]/", "", extract_zipcode($matches[0])) : $matches[0];
}

function contains($needle, $haystack)
{
    return strpos($haystack, $needle) !== false;
}

function _utf8_decode($string)
{
  $tmp = $string;
  $count = 0;
  while (mb_detect_encoding($tmp)=="UTF-8")
  {
    $tmp = utf8_decode($tmp);
    $count++;
  }
  
  for ($i = 0; $i < $count-1 ; $i++)
  {
    $string = utf8_decode($string);
    
  }
  return $string;
  
}


// Complete trim
function _trim($input)
{
return trim(strip_tags(preg_replace("/&#?[a-z0-9]{2,8};/i","",$input)));
}

// Keep special spaces
function keep_spaces($input)
{
return trim(preg_replace('/(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])/i', ' ', preg_replace('/(?<!\ )[A-Z]/', ' $0', $input)));
}


function _curl($url){
    $headers[]  = "User-Agent:Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13";
    $headers[]  = "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
    $headers[]  = "Accept-Language:en-us,en;q=0.5";
    $headers[]  = "Accept-Encoding:gzip,deflate";
    $headers[]  = "Accept-Charset:ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $headers[]  = "Keep-Alive:115";
    $headers[]  = "Connection:keep-alive";
    $headers[]  = "Cache-Control:max-age=0";

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_ENCODING, "");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;

}
function file_get_html_curl($url){
    return str_get_html(utf8_encode(_curl($url)));
}

function dk_strtotime($date) {

$arr = array(
'januar' => 'january', 
'februar' => 'february', 
'marts' => 'march', 
'april' => 'april', 
'maj' => 'may',
'juni' => 'june',
'juli' => 'july',
'august' => 'august',
'september' => 'september',
'oktober' => 'october',
'november' => 'november',
'december' => 'december');


return strtotime(strtr($date,$arr));
}

function extract_emails($string) {
    foreach(preg_split('/\s/', $string) as $token) {
        $email = filter_var(filter_var($token, FILTER_SANITIZE_EMAIL), FILTER_VALIDATE_EMAIL);
        if ($email !== false) {
            $emails[] = $email;
        }
    }
    return $emails;
}