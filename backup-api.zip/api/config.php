<?php

// Settings
define('DEBUG', 1);
define('HTTP_HOST', 'https://eco-info.backup-eco-net.dk/');

// DB credentials
define('DB_STATUS', 1);
define('DB_TYPE', 'mysql');
define('DB_HOST', 'mysql51.unoeuro.com');
define('DB_NAME', 'groentoverblik_dk0_db');
define('DB_USER', 'groentover_dk0');
define('DB_PASS', 'povuki84wefu');
define('DB_PREFIX', 'go_');

define('MAIL_SERVER','mail.unoeuro.com');
define('MAIL_USER','admin@eco-info.dk');
define('MAIL_PASS','admin@eco-info.dk');
define('MAIL_PORT','143');