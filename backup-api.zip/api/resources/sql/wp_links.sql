-- phpMyAdmin SQL Dump
-- version 4.4.15.1
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 13. 08 2016 kl. 10:33:35
-- Serverversion: 5.6.28
-- PHP-version: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xn--grntoverblik-wjb.dk`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `wp_links`
--
DROP TABLE IF EXISTS wp_links;

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL,
  `link_post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `link_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_url` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_rel` tinyint(1) NOT NULL DEFAULT '0',
  `link_done` tinyint(1) NOT NULL DEFAULT '0',
  `link_error` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
