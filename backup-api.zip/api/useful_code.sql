SELECT COUNT( * ) , post_title
FROM  `go_posts` 
WHERE post_type = 'w2dc_listing'
AND post_status = 'publish'
GROUP BY post_title
HAVING COUNT( * ) >1


SELECT COUNT( * ) , post_title
FROM  `go_posts` 
WHERE post_type =  'w2dc_listing'
AND post_status =  'publish'
AND post_content =  ''
GROUP BY post_title


// Remove dublicates
ALTER IGNORE TABLE go_backup
ADD UNIQUE INDEX go_index (title);

ALTER TABLE go_backup
  DROP INDEX go_index;